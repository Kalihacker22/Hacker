from os import system, name
import itertools
import threading 
import time
import sys
import datetime
from base64 import b64decode, b64encode
from datetime import date

expirydate = datetime.date(2025, 12, 30)
today=date.today()
def hero():

	def chalo():
		done = False
		def animate():
			for c in itertools.cycle(['|','/','-','\\']):
				if done:
					break
				sys.stdout.write('\r------- Hacking maurya parity server for next colour -------'+c)
				sys.stdout.flush()
				time.sleep(0.0001)
			sys.stdout.write('\rDone! Server is HACKED ')

		t = threading.Thread(target=animate)
		t.start()
		time.sleep(5)
		done = True

	def chalo1():
		done = False
		def animate():
			for c in itertools.cycle(['|','/','-','\\']):
				if done:
					break
				sys.stdout.write('\r------------------ Getting the colour wait -----------------'+c)
				sys.stdout.flush()
				time.sleep(0.0001)
			sys.stdout.write('\r')

		t = threading.Thread(target=animate)
		t.start()

		time.sleep(1)
		done = True

	def clear():
		if name == 'nt':
			_=system('cls')
		else:
			_=system('clear')

	clear()
	y=1
	c=period
	banner='figlet RXCE'
	thisway=[2,6,8,11,12,15,16,18,19,20]
	thatway=[1,3,4,5,7,9,10,14,13,17]
	numbers=[]
	i=1
	while(y):
		clear()
		system(banner)
		print("maurya parity colour prediction Hack")
		c=(input("Enter current parity number : "))
		print("Enter",c,"Parity Price: ",end='')
		current=input()
		current=int(current)
		c=int(c)
		chalo()
		print("\n------------- Successfully hacked maurya server ------------")
		chalo1()
		print("\n--------------- Successfully got the colour ----------------")
		print("\n")
		def getSum(n):
			sum=0
			for digit in str(n):
				sum += int(digit)
			return sum 
		if i in thisway:
			m=getSum(current)
			n=int(current)%10
			c=int(c)
			if((m%2==0 and n%2==0)or(m%2==1 and n%2==1)):
				if current in numbers:
					print("Parity",a,":RED")
				else:
					print("Parity",a,":GREEN")
			else:
				if current in numbers:
					print("Parity",a,":GREEN")
				else:
					print("Parity",a,":RED")

		if i in thatway:
			m=getSum(current)+1
			n=int(current)%10
			a=c+1
			if((m%2==0 and n%2==0)or(m%2==1 and n%2==1)):
				if current in numbers:
					print("Parity",a,": RED")
				else:
					print("Parity",a,": GREEN")
			else:
				if current in numbers:
					print("Parity",a,": GREEN")
				else:
					print("Parity",a,": RED")
		i=i+1
		c+=1
		numbers.append(current)
		y=input("programmed by Aagam sanghavi \nDo you want to use again : Press 1 and 0 to exit \n")
		if(y==0):
			y=False
		if(len(numbers)>11):
			clear()
			system('figlet Thank You!!')
			print("Play on next specified time!!")
			print("-------Current Time UP-------")
			sys.exit("\n\n\n 777 Color Hack")

if(expirydate>today):
	now = datetime.datetime.now()
	First = now.replace(hour=13,minute=55,second=0,microsecond=0)
	Firstend = now.replace(hour=14,minute=35,second=0,microsecond=0)
	Second = now.replace(hour=15,minute=55,second=0,microsecond=0)
	Secondernd = now.replace(hour=16,minute=35, second=0, microsecond=0)
	Third = now.replace(hour=16,minute=55, second=0, microsecond=0)
	Thirdend= now.replace (hour=17,minute=35, second=0, microsecond=0)
	Final = now.replace(hour=17,minute=55, second=0, microsecond=0)
	Finalend = now.replace (hour=18,minute=18, second=0, microsecond=0)


	if(False):
		period=305
		hero()
	elif(now>First and now<Firstend):
		period=305
		hero()
	elif(now>Third and now<Thirdend):
		period=305
		hero()
	elif(True):
		period=305
		hero()

	else:
		banner='figlet RXCE'
		print("Hi!! Thank for buying the hack")
		print("------Your play time-------")
		print("29 jan 2023,11:00AM- 11:30AM")
		print("29 jan 2023,02:00AM- 02:30AM")
		print("29 jan 2023,05:00AM- 05:30AM")
		print("29 jan 2023,08:00AM- 08:30AM")
		print("Please play on the given time")
else:
	banner='figlet RXCE'
	system(banner)
	print("*-------*-------*--------*-------*")
